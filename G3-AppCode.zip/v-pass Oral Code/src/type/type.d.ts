interface Window{
    ethereum ?: any
}