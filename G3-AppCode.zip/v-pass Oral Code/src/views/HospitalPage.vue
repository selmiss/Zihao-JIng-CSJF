<template>
    <div class="outUser">
        <div class="logo">
            <img src="../assets/logoh.png" style="width:250px" />
        </div>
        <div class="account">
                <div class="cdc" style="display:inline-block;vertical-align: middle;margin-bottom: -10px;">Cdc Account: </div>
            <div style="display:inline-block;vertical-align: top;">
            <n-button class="countButton" @click="goLogin" quaternary type="info">
                
                {{myAccount.slice(0,8)}}...{{myAccount.slice(36)}}
            </n-button>
            </div>
        </div>
        <div class="options">
            <n-breadcrumb>
                <n-breadcrumb-item @click="check(1)">
                <n-icon :component="MdCash" /> Register</n-breadcrumb-item>
                <n-breadcrumb-item @click="check(2)">
                <n-icon :component="MdCash" /> Add Record</n-breadcrumb-item>
                <n-breadcrumb-item @click="check(3)"> 
                <n-icon :component="MdCash" /> Add Vaccine</n-breadcrumb-item>
                <n-breadcrumb-item></n-breadcrumb-item>
            </n-breadcrumb>
        </div>
        <div class="register" v-if="page===1">
        <p style="color:red;margin-top: -20px;">Note: Only administrators can perform this operation！</p>
            <n-form >
                    <n-form-item path="age" label="Hospital Name:">
                    <n-input v-model:value="hospital.name" @keydown.enter.prevent />
                    </n-form-item>
                    <n-form-item path="password" label="Hospital Address:">
                    <n-input
                        v-model:value="hospital.id"
                       
                        @keydown.enter.prevent
                    />

                    </n-form-item>
               <n-row :gutter="[0, 24]">
                <n-col :span="24">
                    <div style="display: flex; justify-content: flex-end">
                    <n-button
                        round
                        type="primary"
                        @click="addHospital(hospital.name,hospital.id)"
                    >
                        Register
                    </n-button>
                    </div>
                </n-col>
                </n-row>
            </n-form>
        </div>
        <div class="register" v-if="page===2">
            <n-form >
                    <n-form-item path="age" label="Patient Address:">
                        <n-input v-model:value="record.user" @keydown.enter.prevent />
                    </n-form-item>
                    <n-form-item path="password" label="Vaccine ID:">
                        <n-input
                            v-model:value="record.id"
                        
                            @keydown.enter.prevent
                        />

                    </n-form-item>
                    <n-form-item path="password" label="Vaccine Name:">
                        <n-input
                            v-model:value="record.name"
                        
                            @keydown.enter.prevent
                        />

                    </n-form-item>
               <n-row :gutter="[0, 24]">
                <n-col :span="24">
                    <div style="display: flex; justify-content: flex-end">
                    <n-button
                        round
                        type="primary"
                        @click="addRecord(record.user,record.name,record.id)"
                    >
                        Upload
                    </n-button>
                    </div>
                </n-col>
                </n-row>
            </n-form>
        </div>
        <div class="register" v-if="page===3">
        <p style="color:red;margin-top: -20px;">Note: Only administrators can perform this operation！</p>
            <n-form>
                    <n-form-item path="age" label="Vaccine Name:">
                        <n-input v-model:value="vaccine.name" @keydown.enter.prevent />
                    </n-form-item>
                    <n-form-item path="password" label="Vaccine ID:">
                        <n-input
                            v-model:value="vaccine.id"
                        
                            @keydown.enter.prevent
                        />

                    </n-form-item>
                    
               <n-row :gutter="[0, 24]">
                <n-col :span="24">
                    <div style="display: flex; justify-content: flex-end">
                    <n-button
                        round
                        type="primary"
                        @click="addVaccineRaw(vaccine.name,vaccine.id)"
                    >
                        Upload
                    </n-button>
                    </div>
                </n-col>
                </n-row>
            </n-form>
        </div>
    </div>
</template>
<script setup lang="ts">
import Web3 from 'web3'
import {ref} from 'vue'
import { Icon } from '@vicons/utils'
import { Copy16Regular } from '@vicons/fluent'
import axios from 'axios'
import requests from '../request'
import { sleep } from 'seemly'
import {onMounted} from 'vue'
import {useRouter} from 'vue-router'
import utils  from '@/Utils'
import { MdCash } from '@vicons/ionicons4'

const router = useRouter()
let page = ref(1);
let contractAddr = ''
let myAccount = ref("")
let hospital= ref({name:'',id:''})
let record = ref({user:'',name:'',id:''})
let vaccine  = ref({name:'',id:''})

const goLogin = () => {
    router.push('/')
}
async function addHospital(name:string,addr:string){
    let data = await requests.getFunc('createHospital(string,address)')
    data += '0000000000000000000000000000000000000000000000000000000000000040'
    data = requests.addAddress(data,addr.slice(2))
    data = requests.addParamsString(data,name)
    const transactionHash = await window.ethereum.request({
        method:'eth_sendTransaction',
        params:[
            {
                'to' : contractAddr,
                'from': myAccount.value,
                'data': data,
                
                "gasPrice": "0x84e72a000",

            }
        ],
    });
}
async function addRecord(user:string,name:string,id:string){
    let data = await requests.getFunc('addVaccine(address,string,string,string)')
    data = requests.addAddress(data,user.slice(2));
    data += '0000000000000000000000000000000000000000000000000000000000000080'
    data += '00000000000000000000000000000000000000000000000000000000000000c0'
    data += '0000000000000000000000000000000000000000000000000000000000000100'
    data = requests.addParamsString(data,name)
    let nowDate = new Date();
    let strDate = nowDate.getMonth()+'/' +nowDate.getDate()+'/'+ nowDate.getFullYear()
    data = requests.addParamsString(data,strDate)
    data = requests.addParamsString(data,id)
    const transactionHash = await window.ethereum.request({
        method:'eth_sendTransaction',
        params:[
            {
                'to' : contractAddr,
                'from': myAccount.value,
                'data': data, 
                "gasPrice": "0x84e72a000",
            }
        ],
    });
}
async function addVaccineRaw(name:string,id:string){
    let data = await requests.getFunc('addVaccineRaw(string,string,string)')
    data += '0000000000000000000000000000000000000000000000000000000000000060'
    data += '00000000000000000000000000000000000000000000000000000000000000a0'
    data += '00000000000000000000000000000000000000000000000000000000000000e0'
    data = requests.addParamsString(data,name)
    data = requests.addParamsString(data,id)
    let nowDate = new Date();
    let strDate = nowDate.getMonth()+'/' +nowDate.getDate()+'/'+ nowDate.getFullYear()
    data = requests.addParamsString(data,strDate)
    const transactionHash = await window.ethereum.request({
        method:'eth_sendTransaction',
        params:[
            {
                'to' : contractAddr,
                'from': myAccount.value,
                'data': data, 
                "gasPrice": "0x84e72a000",
            }
        ],
    });
}
onMounted(()=>{
    myAccount.value = utils.getCookie('account')
    contractAddr = utils.getCookie('contract')
})
const check = (target:number) => {
    page.value = target;
}
</script>
<style scoped>
.register{
    text-align: center;
    margin-left: auto;
    margin-right: auto;
    width: 80%;
}
.cdc{
    font-size: larger;
    font-weight: 700;
}
.outUser {
    width: 100%;
    max-width: 400px;
    height: 600px;
    border:1px solid rgb(181, 222, 218);
    margin-left: auto;
    margin-right: auto;
    text-align: center;
    box-shadow:15px 15px 15px rgba(0, 0, 0, 0.034),15px -15px 15px rgba(0, 0, 0, 0.034),-15px 15px 15px rgba(0, 0, 0, 0.034),-15px -15px 15px rgba(0, 0, 0, 0.034);
}
.account{
    text-align: center;
    border-bottom:1px solid rgb(181, 222, 218);
    margin-top: -40px;
}
</style>