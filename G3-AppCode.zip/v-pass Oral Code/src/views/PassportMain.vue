<template>
    <div class="out">
        <div class="left">
            <div class="self">
                <p>passportNo : {{passportNo}} 
                <Icon>
                    <Copy16Regular />
                </Icon></p>
                <p>Name : {{name}}</p>
                <p>Nation : {{nation}}</p>
                <p>Phone : {{phone}}</p>
            </div>
            <div class="photo" >
                <img src="../assets/jzh.jpg" style="width: 130px;"/>
            </div>
            <div class="buttons">
                 <ul id="buttonList">
                    <li>
                        <n-button class="funcButton" strong secondary @click="toUserPage" type="tertiary">
                           <span>Re</span> 
                        </n-button>
                        <div class="disButton">
                            V-records
                        </div>
                        
                    </li>
                    <li>
                        <n-button class="funcButton" strong secondary @click="toUserPage" type="tertiary">
                            <span>Qu</span> 
                        </n-button>
                        <div class="disButton">
                            V-query
                        </div>
                    </li>
                    <li>
                        <n-button class="funcButton" strong secondary @click="toUserPage" type="tertiary">
                            <span>Ho</span> 
                        </n-button>
                        <div class="disButton">
                            Hospitals
                        </div>
                    </li>
                    <li>
                        <n-button class="funcButton" strong secondary @click="toUserPage" type="tertiary">
                            <span>Se</span> 
                        </n-button>
                        <div class="disButton">
                            Self-Info
                        </div>
                    </li>
                 </ul>
            </div>
            <div class="qrcode">
                <img src="../assets/qrtitle.jpg" style="width: 150px;margin-bottom: 40px;"/>
                <img src="../assets/qrcode.jpg" style="width: 150px;"/>
            </div>
        </div>
        <div class="infolist">
             <p style="font-size:x-large;margin-top:-10px">Vaccination</p>
            <n-list hoverable clickable>
               
                <n-list-item v-bind:key="item.id" v-for="item in RecordList">
                    
                    <n-tag :bordered="false" type="info" size="small">
                        {{item.name}}
                    </n-tag>
                    <a href="" style="margin-left:20px;">{{item.id}}</a>
                    => {{item.time}}
                </n-list-item>

            </n-list>
        </div>
    </div>
</template>

<script setup lang="ts">
import Web3 from 'web3'
import {onMounted, ref} from 'vue'
import { Icon } from '@vicons/utils'
import { Copy16Regular } from '@vicons/fluent'
import axios from 'axios'
import requests from '../request'
import { sleep } from 'seemly'
import utils from '@/Utils'
import {useRouter} from 'vue-router'

let name = ref('Fancy Kilig')
let id = ref('0a1bc3455')
let nation = ref('China')
let phone = ref('+86 18811591037')
let passportNo = ref('')
const router = useRouter()

let contractAddr = ''
let myAccount = ref('')
let RecordList = ref([{name:'Loading',id:'Please wait...',time:''}])
// let VaccineList = ref([{name:'Loading',id:'Please wait...',time:''}])
// let HospitalList = ref([{name:'Loading',id:'Please wait...',address:'0x00000'}])

const functions = ['vaccineCountAll()','vaccines(uint256)','hospitalCount()'
    ,'hospitalArray(uint256)','getUserVacc(address,uint32)','getUserVaccCount(address)']

const toUserPage = () => {
    router.push('/userpage')
}
function getAccount(){
    requests.eth_accounts();
}
function testAccount(){
    if(window.ethereum){
        window.ethereum.enable().then(res=>{
            alert(res[0])
            myAccount = res[0]
        })
    }
    else{
        alert('no wallet')
    }
}
async function sendTransaction(){
    let func = 'createUser(string,address)'
    let data = await requests.getFunc(func)
    let name = 'selmiss'
    data = requests.strPre2(data)
    data = requests.addAddress(data,myAccount.value.slice(2))

    data = requests.addParamsString(data,name)
    //requests.eth_sendTransaction(contractAddr,data)
    console.log(data)
    const transactionHash = await window.ethereum.request({
        method:'eth_sendTransaction',
        params:[
            {
                'to' : contractAddr,
                'from': myAccount,
                'data': data,
                "gas": "0x76c0",
                "gasPrice": "0x9184e72a000",
                "value": "0x9184e72a"
            }
        ],

    });
    console.log(transactionHash)
}
async function initialize_Record(){
    let data = await requests.getFunc(functions[5])
    data = requests.addAddress(data,myAccount.value.slice(2))
    let re = await requests.eth_call(contractAddr,data)
    const len = requests.hex2dec(re)
    let array = [];
    for(let i=0;i<len;i++){
        data = await requests.getFunc(functions[4])
        data = requests.addAddress(data,myAccount.value.slice(2))
        data = requests.addParamsNum(data,i)
        re = await requests.eth_call(contractAddr,data)
        console.log(re)
        let name = requests.str_decode(re,4)
        let id = requests.str_decode(re,6)
        let time = requests.str_decode(re,8)
        array.push({name:name,id:id , time:time})
    }
    RecordList.value = array;
}
async function getUser() {
    let data = await requests.getFunc('getUserInfo(address)')
    data = requests.addAddress(data,myAccount.value.slice(2))
    let re = await requests.eth_call(contractAddr,data)
    console.log(re)
    passportNo.value = '0x'+ requests.str_decode(re,7)
}
onMounted(()=>{
    myAccount.value = utils.getCookie('account')
    contractAddr = utils.getCookie('contract')
    getUser()
    initialize_Record();
})
</script>

<style scoped>
@import url('../assets/index.css');

</style>