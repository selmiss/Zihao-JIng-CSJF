<template>
    <div class="outUser">
        <div class="logo">
            <img src="@/assets/v-pass.png" style="width:250px" />
        </div>
        <div class="account">
                <div style="display:inline-block;vertical-align: bottom;"><img src="@/assets/MyAccount.png" style="width:130px;margin-bottom: -7px;" />  </div>
            <div style="display:inline-block;vertical-align: top;">
            <n-button class="countButton" @click="goLogin" quaternary type="info">
                
                {{AccountShow.slice(0,8)}}...{{AccountShow.slice(36)}}
            </n-button>
            </div>
        </div>
        <div class="buttons2">
        <div class="buttons">
                
                 <ul id="buttonList">
                    <li>
                        <n-button class="funcButton" @click="check(1)" strong secondary  type="tertiary">
                           <span>Re</span> 
                        </n-button>
                        <div class="disButton">
                            V-records
                        </div>
                        
                    </li>
                    <li>
                        <n-button class="funcButton" @click="check(2)" strong secondary  type="tertiary">
                            <span>Va</span> 
                        </n-button>
                        <div class="disButton">
                            Vaccines
                        </div>
                    </li>
                    <li>
                        <n-button class="funcButton" @click="check(3)" strong secondary  type="tertiary">
                            <span>Ho</span> 
                        </n-button>
                        <div class="disButton">
                            Hospitals
                        </div>
                    </li>
                    <li>
                        <n-button class="funcButton" @click="goPassport" strong secondary type="tertiary">
                            <span>Se</span> 
                        </n-button>
                        <div class="disButton">
                            SelfInfo
                        </div>
                    </li>
                 </ul>
            </div>
        </div>
        <div class="records" v-if="page===1">
        <p style="font-size:large;color:skyblue;margin-left: 50px;">Records:</p>
             <div class="infolist2">
                
            <n-list hoverable clickable>
                
                <n-list-item v-bind:key="item.id" v-for="item in RecordList">
                    
                    <n-tag :bordered="false" type="info" size="small">
                        {{item.name}}
                    </n-tag>
                    <a href="" style="margin-left:20px;">{{item.id}}</a>
                    => {{item.time}}
                </n-list-item>

            </n-list>
        </div>
        </div>
        <div class="records" v-if="page===2">
        <p style="font-size:large;color:skyblue;margin-left: 50px;">Vaccines:</p>
             <div class="infolist2">
                
            <n-list hoverable clickable>
                
                <n-list-item v-bind:key="item.id" v-for="item in VaccineList">
                    
                    <n-tag :bordered="false" type="warning" size="small">
                        {{item.name}} 
                    </n-tag>
                    <a href="" style="margin-left:20px;">{{item.id}}</a>
                    {{item.time}}
                </n-list-item>

            </n-list>
        </div>
        </div>
        <div class="records" v-if="page===3">
        <p style="font-size:large;color:skyblue;margin-left: 50px;">Hospitals:</p>
             <div class="infolist2">
                
            <n-list hoverable clickable>
                
                <n-list-item v-bind:key="item.id" v-for="item in HospitalList">
                    
                    <n-tag round style="margin-right:10px" :bordered="false" type="warning" size="small">
                        {{item.name}}
                    </n-tag>
                    id:{{item.id}}
                    <a href="" style="margin-left:20px;">{{item.address.slice(0,10)}}...{{item.address.slice(34)}}</a>
                </n-list-item>

            </n-list>
        </div>
        </div>
    </div>
</template>
<script setup lang="ts">
import Web3 from 'web3'
import {ref} from 'vue'
import { Icon } from '@vicons/utils'
import { Copy16Regular } from '@vicons/fluent'
import axios from 'axios'
import requests from '../request'
import { sleep } from 'seemly'
import {onMounted} from 'vue'
import {useRouter} from 'vue-router'
import utils  from '@/Utils'
const router = useRouter()
let page = ref(1);
let contractAddr = ''
let myAccount = ""
let AccountShow = ref('')

let RecordList = ref([{name:'Loading',id:'Please wait...',time:''}])
let VaccineList = ref([{name:'Loading',id:'Please wait...',time:''}])
let HospitalList = ref([{name:'Loading',id:'Please wait...',address:'0x00000'}])

const functions = ['vaccineCountAll()','vaccines(uint256)','hospitalCount()'
    ,'hospitalArray(uint256)','getUserVacc(address,uint32)','getUserVaccCount(address)']

const goLogin = () => {
    router.push('/')
}
const goPassport = () => {
    router.push('/passport')
}
async function initialize_VaccineList() {
    let data = await requests.getFunc(functions[0])
    let re = await requests.eth_call(contractAddr,data)
    const len = requests.hex2dec(re)
    let array = [];
    for(let i=0;i<len;i++){
        data = await requests.getFunc(functions[1])
        data = requests.addParamsNum(data,i)
        re = await requests.eth_call(contractAddr,data)
        let name = requests.str_decode(re,3)
        let id = requests.str_decode(re,5)
        let time = requests.str_decode(re,7)
        array.push({name:name,id:id , time:time})
    }
    VaccineList.value = array;
}   
async function initialize_HospitalList() {
    let data = await requests.getFunc(functions[2])
    let re = await requests.eth_call(contractAddr,data)
    const len = requests.hex2dec(re)
    let array = [];
    for(let i=0;i<len;i++){
        data = await requests.getFunc(functions[3])
        data = requests.addParamsNum(data,i)
        re = await requests.eth_call(contractAddr,data)
        console.log(re)
        let name = requests.str_decode(re,3)
        let id = requests.hex2dec(re.slice(0,66)).toString()
        let  addr = requests.addr_decode(re,2)
        array.push({name:name,id:id,address:addr})
    }
    HospitalList.value = array;
}
async function initialize_Record(){
    let data = await requests.getFunc(functions[5])
    data = requests.addAddress(data,myAccount.slice(2))
    let re = await requests.eth_call(contractAddr,data)
    const len = requests.hex2dec(re)
    let array = [];
    for(let i=0;i<len;i++){
        data = await requests.getFunc(functions[4])
        data = requests.addAddress(data,myAccount.slice(2))
        data = requests.addParamsNum(data,i)
        re = await requests.eth_call(contractAddr,data)
        console.log(re)
        let name = requests.str_decode(re,4)
        let id = requests.str_decode(re,6)
        let time = requests.str_decode(re,8)
        array.push({name:name,id:id , time:time})
    }
    RecordList.value = array;
}
onMounted(()=>{
    AccountShow.value = utils.getCookie('account')
    myAccount = utils.getCookie('account')
    contractAddr = utils.getCookie('contract')
    
    initialize_VaccineList();
    initialize_HospitalList();
    initialize_Record();
})
const check = (target:number) => {
    page.value = target;
}



</script>
<style scoped>
@import url('../assets/index.css');
@import url('../assets/user.css');

</style>