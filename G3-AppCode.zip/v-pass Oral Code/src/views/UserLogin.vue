<template>
    <div class="outUser">
         <div class="logo">
            <img src="@/assets/v-pass.png" style="width:250px" />
        </div>
         <div class="account">
                <div style="display:inline-block;vertical-align: bottom;"><img src="@/assets/MyAccount.png" style="width:130px;margin-bottom: -7px;" />  </div>
            <div style="display:inline-block;vertical-align: top;">
            <n-button class="countButton" quaternary type="info">
                
                {{myAccount.slice(0,8)}}...{{myAccount.slice(36)}}
            </n-button>
            </div>
        </div>
        <div class="button1">
             <n-button size="large" style="margin-right:10px" @click="signAccount" strong secondary type="primary">
                Sign In
            </n-button>
            <n-button size="large" @click="logout" strong secondary type="warning">
                Log Out
            </n-button>
             
        </div>
        <div class="button2">
            <n-popover placement="right" trigger="click">
                <template #trigger>
                <n-button size="large" strong secondary type="info">
                    Binding a passport
                </n-button>
                </template>
                <div class="binding" style="width:150px;text-align: center;">
                <n-input v-model:value="passportNo" type="text" placeholder="Input your passportNo" />
                <n-input v-model:value="name" type="text" placeholder="Input your name" />
                <n-button strong @click="bindPassport" secondary type="info">
                    Confirm
                </n-button>
                </div>
            </n-popover>
            
        </div>
        <div class="logo" style="margin-top:30px;margin-left:5px">
            <img src="@/assets/message3.png" style="width:350px" />
        </div>
    <n-config-provider >
    <n-modal
        v-model:show="showModalRef"
        :mask-closable="false"
        preset="dialog"
        sytle="width:150px"
        title="Your role?"
    >
    <div style="width:100%;text-align: center;">
        <n-button strong secondary @click="toUser" type="primary">
        User
        </n-button>
        <n-button style="margin-left:10px" @click="toHospital" strong secondary type="info">
        Hospital
        </n-button>
        </div>
    </n-modal>
    </n-config-provider>
    </div>
</template>
<script setup lang="ts">
import Web3 from 'web3'
import {ref} from 'vue'
import { Icon } from '@vicons/utils'
import { Copy16Regular } from '@vicons/fluent'
import axios from 'axios'
import requests from '../request'
import { sleep } from 'seemly'
import {onMounted} from 'vue'
import utils from '@/Utils'
import { useRouter } from 'vue-router'
import { now } from 'lodash'

let myAccount = ref("NaN")
let passportNo = ref('')
let name = ref('')
let showModalRef = ref(false)
const router = useRouter()
const contractAddr = '0x242a40317db779ff227a6a7E8Dc1eCcc57aa0CE7'
const functions = ['createUser(string,string,address)','createHospital(string,address)']
const toUser =() => {
    router.push('/userpage')
}

const toHospital =() => {
    router.push('/hospitalpage')
}
function signAccount(){
    if(window.ethereum){
        window.ethereum.enable().then(res=>{
            myAccount.value = res[0];
            utils.setCookie('account',myAccount.value)
            utils.setCookie('contract',contractAddr)
            showModalRef.value=true;
        })
    }
    else{
        alert('Please install metaMask!')
    }
}
const logout = () => {
    utils.setCookie('account','')
    myAccount.value = ''
}
async function bindPassport(){
    let data = await requests.getFunc(functions[0])
    data = data + '000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a0'
    data = requests.addAddress(data,myAccount.value.slice(2))
    data = requests.addParamsString(data,name.value)
    data = requests.addParamsString(data,passportNo.value)
    console.log(data)
    const transactionHash = await window.ethereum.request({
        method:'eth_sendTransaction',
        params:[
            {
                'to' : contractAddr,
                'from': myAccount.value,
                'data': data,

                "gasPrice": "0x184e72a000",

            }
        ],
    });
    console.log(transactionHash)
}
async function addHospital(name:string,addr:string){
    let data = await requests.getFunc('createHospital(string,address)')
    data += '0000000000000000000000000000000000000000000000000000000000000040'
    data = requests.addAddress(data,addr.slice(2))
    data = requests.addParamsString(data,name)
    const transactionHash = await window.ethereum.request({
        method:'eth_sendTransaction',
        params:[
            {
                'to' : contractAddr,
                'from': myAccount.value,
                'data': data,
                
                "gasPrice": "0x84e72a000",

            }
        ],
    });
}
async function addVaccineRaw(name:string,id:string){
    let data = await requests.getFunc('addVaccineRaw(string,string,string)')
    data += '0000000000000000000000000000000000000000000000000000000000000060'
    data += '00000000000000000000000000000000000000000000000000000000000000a0'
    data += '00000000000000000000000000000000000000000000000000000000000000e0'
    data = requests.addParamsString(data,name)
    data = requests.addParamsString(data,id)
    let nowDate = new Date();
    let strDate = nowDate.getMonth()+'/' +nowDate.getDate()+'/'+ nowDate.getFullYear()
    data = requests.addParamsString(data,strDate)
    const transactionHash = await window.ethereum.request({
        method:'eth_sendTransaction',
        params:[
            {
                'to' : contractAddr,
                'from': myAccount.value,
                'data': data, 
                "gasPrice": "0x84e72a000",
            }
        ],
    });
}
async function addRecord(user:string,name:string,id:string){
    let data = await requests.getFunc('addVaccine(address,string,string,string)')
    data = requests.addAddress(data,user.slice(2));
    data += '0000000000000000000000000000000000000000000000000000000000000080'
    data += '00000000000000000000000000000000000000000000000000000000000000c0'
    data += '0000000000000000000000000000000000000000000000000000000000000100'
    data = requests.addParamsString(data,name)
    let nowDate = new Date();
    let strDate = nowDate.getMonth()+'/' +nowDate.getDate()+'/'+ nowDate.getFullYear()
    data = requests.addParamsString(data,strDate)
    data = requests.addParamsString(data,id)
    const transactionHash = await window.ethereum.request({
        method:'eth_sendTransaction',
        params:[
            {
                'to' : contractAddr,
                'from': myAccount.value,
                'data': data, 
                "gasPrice": "0x84e72a000",
            }
        ],
    });
}
onMounted(()=>{
    myAccount.value = utils.getCookie('account')
})
</script>

<style scoped>
.button1{
    margin-top: 30px;
    margin-bottom: 30px;
}
.account{
    text-align: center;
    border-bottom:1px solid rgb(181, 222, 218);
    margin-top: -40px;
}
.outUser {
    width: 100%;
    max-width: 400px;
    height: 600px;
    border:1px solid rgb(181, 222, 218);
    margin-left: auto;
    margin-right: auto;
    text-align: center;
    box-shadow:15px 15px 15px rgba(0, 0, 0, 0.034),15px -15px 15px rgba(0, 0, 0, 0.034),-15px 15px 15px rgba(0, 0, 0, 0.034),-15px -15px 15px rgba(0, 0, 0, 0.034);
}
</style>