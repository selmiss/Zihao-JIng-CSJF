import { def } from '@vue/shared'
import axios from 'axios'
const postAddress = "https://ropsten.infura.io/v3/bc05c4b49d9f4624b5aa87ae3b2e80c5"
const myAccount = "0x5ECB06F07F7992777aCe43f6902201daDdac796C"
const strPrex = '00000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000080'
const strPrex2 = '0000000000000000000000000000000000000000000000000000000000000040'
const frameDs = {
    "jsonrpc": "2.0",
    "method":"",
    "params":[  {}  ],
    "id":1
}
const requests = {
    async web3_clientVersion(){
        frameDs['params']=[]
        frameDs['method']="web3_clientVersion"
        axios.post(postAddress,frameDs).then(res=>{
            console.log(res.data)
        })
    },
    async eth_sendTransaction(to:string,data:string){
        const params = [{
            "from": myAccount,
            "to": to,
            "gas": "0x76c0", // 30400
            "gasPrice": "0x9184e72a000", // 10000000000000
            "value": "0x9184e72a", // 2441406250
            "data": data
        }]
        frameDs['params']=params
        frameDs['method']="eth_sendTransaction"
        console.log(frameDs)
        axios.post(postAddress,frameDs).then(res=>{
            console.log(res.data)
        })
    },
    async eth_call (to:string,data:string) {
        const params = [{
            "to": to,
            "data":data
        },"latest"]
        frameDs['params']=params
        frameDs['method']="eth_call"
        console.log(frameDs)
        let re = ''
        await axios.post(postAddress,frameDs).then(res=>{
            console.log(res.data)
            re = res.data.result
            //console.log(re)
            
        })
        return re
    },
    async eth_accounts(){
        frameDs['params']=[];
        frameDs['method']='eth_accounts'
        await axios.post(postAddress,frameDs).then(res=>{
            console.log(res.data)
        })

    },
    //将字符串转换为16进制,不含0x
    stringToHex(str:string){
            let val="";
                for(let i = 0; i < str.length; i++){
                if(val == "")
                        val = str.charCodeAt(i).toString(16);
                    else
                        val += str.charCodeAt(i).toString(16);
            }
            return val;
    },
    //对字符串取哈希值
    async str_sha3(str:string){
        const restr = '0x'+this.stringToHex(str);
        
        const params = [restr];
        frameDs['params']=params
        frameDs['method']="web3_sha3"
        console.log(frameDs)
        let result = '';
        await axios.post(postAddress,frameDs).then(res=>{
             result = res.data.result
             //console.log('re'+result)
        })
        return result;
    },
    async getFunc(str:string){
        let data = await this.str_sha3(str)
        data = data.slice(0,10)
        return data;
    },
    addParamsNum(str:string,num:number){
        const num_temp = num.toString(16);
        let num_re = ''
        if(num_temp.length<64){
            for(let i=0;i<64-num_temp.length;i++)
            {
                num_re+='0'
            }
        }
        num_re+=num_temp;
        return str+num_re;
    },
    addAddress(str:string,addr:string){
        let add_re = ''
        if(addr.length<64){
            for(let i=0;i<64-addr.length;i++)
            {
                add_re+='0'
            }
        }
        add_re+=addr;
        return str+add_re;
    },
    addParamsString(str:string,s:string){
        const len = s.length;
        const len_str = this.addParamsNum('',len)
        let s_temp = this.stringToHex(s)

        for(let i=0;i<64-len*2%64;i++)
        {
            s_temp+='0'
        }

        return str+len_str+s_temp;
    },
    //16转10进制
    hex2dec(str:string){
        const s = str.slice(2)
        return parseInt(s,16)
    },
    // 字符串20 80前缀
    strPre(str:string){
        return str+strPrex;
    },
    strPre2(str:string){
        return str+strPrex2;
    },
    //解码小于32字符的字符串,输入0x开头
    str_decode(restr:string,start:number){
        const str = restr.slice(2)
        const a=start*64;
        const len = str.slice(a,a+64)
        const leng = parseInt(len,16)
        const ori_code = str.slice(a+64,a+128)
        let val=''
        for(let i = 0; i < leng; i++){
            val += String.fromCharCode(parseInt(ori_code.substr(i*2,2),16));
        }
        return val;
    },
    addr_decode(restr:string,start:number){
        const str = restr.slice(2)
        const a=start*64;


        const ori_code = str.slice(a,a+64)
        console.log(ori_code)
        const val = ori_code.slice(24,64)
        
        return '0x'+val;
    }
}
export default requests

